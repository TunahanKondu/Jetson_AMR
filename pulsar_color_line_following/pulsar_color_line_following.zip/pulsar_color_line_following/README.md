# pulsar_color_line_following

ROS 2 Humble package for orange-line detection, alignment-safe motion control,
encoder-distance completion and optional RTP/H.264 streaming.

## Build

```bash
cd ~/ros2_ws
colcon build --packages-select pulsar_color_line_following --symlink-install
source install/setup.bash
```

## Launch with streaming

```bash
ros2 launch pulsar_color_line_following color_line_following.launch.py \
  show_image:=true \
  gstreamer_enabled:=true \
  gstreamer_host:=172.20.10.6 \
  gstreamer_port:=5000
```

The RealSense ROS driver must publish
`/camera/camera/color/image_raw`. Send `LINE_START` to enable processing:

```bash
ros2 topic pub --once /robot_action std_msgs/msg/String "{data: 'LINE_START'}"
```

Receiver:

```bash
gst-launch-1.0 udpsrc port=5000 caps="application/x-rtp,media=video,encoding-name=H264,payload=96" ! rtph264depay ! avdec_h264 ! videoconvert ! autovideosink sync=false
```
